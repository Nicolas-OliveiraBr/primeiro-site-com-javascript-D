let nascimento = prompt("Digite seu ano de nascimento: ")

let nome = prompt("Digite o seu nome aqui")

var x = 2045

var y = x - nascimento

let mensagem = `Olá, seu nome é ${nome} e você tem ${y} anos.`

alert(mensagem)


